<?php

$conn= mysqli_connect("localhost","root","","ers");

if(!$conn)
{
    die('Couldnot connect to database .mysqli_error()');
}

?>